#pragma once

#include <map>
#include <chrono>

class Session
{
public:
	virtual void terminate() = 0;
	virtual bool isTimeout() = 0;
	virtual void setTimeout(uint64_t) = 0;

private:
	std::chrono::seconds m_timeout;
};

template<typename SessionType, typename KeyType>
class SessionManager
{
public:
	virtual void begin() = 0;
	virtual void createSession(KeyType) = 0;
	virtual void terminateSession(KeyType) = 0;
	virtual void updateSessions() = 0;
	virtual SessionType& getSessionInformation(KeyType) = 0;

private:
	std::map<KeyType, SessionType> m_sessions;
};
