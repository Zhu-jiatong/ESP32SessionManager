#pragma once
#include "SessionManagerInterface.h"

class ClientSession : private Session
{
};

