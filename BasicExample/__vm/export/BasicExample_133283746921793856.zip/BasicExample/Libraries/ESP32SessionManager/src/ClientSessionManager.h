#pragma once
#include "SessionManagerInterface.h"
#include "ClientSession.h"
#include <random>
#include <functional>
#include <string>
#include <mbedtls/sha256.h>

class ClientSessionManager :
    private SessionManager<ClientSession, const char*>
{
public:
    void createSession();
    void terminateSession();

private:
    std::string generateID();
};

