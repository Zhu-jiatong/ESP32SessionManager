#include "ClientSessionManager.h"

ClientSessionManager::ClientSessionManager(
	std::function<void(ClientSession, const char*)>& fn_storeSession,
	std::function<void(const char*)>& fn_deleteSession,
	std::function<void(const char*)>& fn_retrieveSession,
	std::function<bool()>& fn_authenticateSession
)
	: SessionManager{ fn_storeSession, fn_deleteSession, fn_retrieveSession, fn_authenticateSession }
{
}

void ClientSessionManager::createSession(uint32_t clientIpAddress)
{
	std::shared_ptr<uint8_t[32]> sessionId = generateId(clientIpAddress);
	ClientSession sessionData("hello");
	m_fn_storeSession(sessionData, sessionId.get());
}

void ClientSessionManager::terminateSession(uint8_t* sessionId)
{
	m_fn_deleteSession(sessionId);
}

std::shared_ptr<uint8_t[32]> ClientSessionManager::generateId(uint32_t clientIpAddress)
{
	std::shared_ptr<uint8_t[32]> output(new uint8_t[32], std::default_delete<uint8_t[]>());

	auto timestamp = std::chrono::high_resolution_clock::now();
	auto period = std::chrono::duration_cast<std::chrono::nanoseconds>(timestamp - initialTimestamp).count();
	
	std::ostringstream ss;
	ss << period << clientIpAddress;
	const std::string& inputStr = ss.str();
	const char* inputCstr = inputStr.c_str();

	mbedtls_sha256_ret(reinterpret_cast<const uint8_t*>(inputCstr), strlen(inputCstr), output.get(), 0);
	return output;
}
