#pragma once
#include "SessionManagerInterface.h"

class ServerSession :
	public Session<uint32_t>
{
};

