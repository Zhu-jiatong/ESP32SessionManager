#pragma once
#include "SessionManagerInterface.h"

class ClientSession : public Session
{
	using Session::Session;
};

