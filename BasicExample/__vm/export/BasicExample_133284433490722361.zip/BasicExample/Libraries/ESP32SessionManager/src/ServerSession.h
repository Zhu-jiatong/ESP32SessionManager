#pragma once
#include "SessionManagerInterface.h"

class ServerSession :
    private Session
{
};

